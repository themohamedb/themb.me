Hiddo icons v1 — 56 icons (42 core, 14 Somali). 24px grid, 1.5px stroke, round caps and joins.
Stroke is #1A1714; swap it for currentColor in code. Free for every Somali team to use.
https://themb.me/hiddo
