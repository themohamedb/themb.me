Hiddo icons v1 — 57 icons (43 core, 14 Somali). 24px grid, 1.5px stroke, round caps and joins.
Stroke is #1A1714; swap it for currentColor in code. Free for every Somali team to use.
https://themb.me/hiddo
